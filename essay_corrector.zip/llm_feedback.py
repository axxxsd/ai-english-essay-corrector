# -*- coding: utf-8 -*-
"""
llm_feedback.py
调用大语言模型 API 获取作文深度点评。

设计原则：
1. 零第三方依赖：仅使用 Python 标准库（urllib），避免 pip 安装问题。
2. 兼容多种服务商：
   - OpenAI / DeepSeek / 通义千问 等均采用「OpenAI 兼容」的
     /v1/chat/completions 接口 + Bearer Token 鉴权，统一处理；
   - 百度文心一言采用 access_token 鉴权，单独处理。
3. 所有函数均接收 ApiConfig 对象，配置集中由 api_config.py 管理。

对外主函数：
- get_llm_feedback(essay, config) -> str            # 获取完整点评
- test_connection(config) -> (ok: bool, msg: str)   # 测试连通性
"""

import json
import urllib.request
import urllib.error
import urllib.parse

from api_config import ApiConfig
from prompt_config import PromptConfig, load_prompts  # 自定义提示词


# ============================================================
# 对外主函数（提示词由 prompt_config 统一管理，用户可在界面编辑）
# ============================================================
def _get_prompts() -> PromptConfig:
    """获取当前提示词配置（空值自动回退默认）。"""
    return load_prompts()


def _build_prompt(essay: str, issues: str = "") -> tuple:
    """
    构造作文点评的 (system, user) 提示词。
    优先使用用户在界面自定义的提示词；若为空则回退默认。
    issues：本地已检出的问题摘要（可空）。
    """
    prompts = _get_prompts()
    msgs = prompts.build_feedback_messages(essay, issues)
    return msgs[0]["content"], msgs[1]["content"]


# ------------------------- 通用 HTTP 请求 -------------------------
def _post_json(url: str, payload: dict, headers: dict, timeout: int) -> dict:
    """
    发送 POST 请求（JSON），返回解析后的 dict。
    统一处理 HTTP 错误，便于上层转为友好提示。

    说明：urllib.request.urlopen 的 timeout 只接受「单一数值」（秒），
    不支持 (connect, read) 元组——传入元组会在内部触发
    "tuple object cannot be interpreted as an integer" 报错。
    因此这里统一用一个较大的超时值（大模型推理较慢，需留足时间）。
    """
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url, data=data, headers=headers, method="POST"
    )
    # 大模型推理可能较慢，确保超时足够长（至少 120 秒）
    total_timeout = max(int(timeout), 120)
    with urllib.request.urlopen(req, timeout=total_timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _extract_content(resp: dict) -> str:
    """从 OpenAI 兼容响应中提取回复文本。"""
    return resp["choices"][0]["message"]["content"]


# ------------------------- 文心一言鉴权 -------------------------
def _get_wenxin_access_token(api_key: str, api_url: str, timeout: int) -> str:
    """
    文心一言使用 client_id/client_secret 换取 access_token。
    注意：界面上的 api_key 建议填写为 "client_id:client_secret" 形式。
    """
    # 若用户在界面填的是 "id:secret" 则拆分，否则按 id=api_key 处理
    if ":" in api_key:
        client_id, client_secret = api_key.split(":", 1)
    else:
        # 兼容：若只填了 access_token 本身，直接返回
        if api_key.startswith("24.") or len(api_key) > 40:
            return api_key
        client_id, client_secret = api_key, ""

    token_url = (
        "https://aip.baidubce.com/oauth/2.0/token"
        f"?grant_type=client_credentials&client_id={urllib.parse.quote(client_id)}"
        f"&client_secret={urllib.parse.quote(client_secret)}"
    )
    req = urllib.request.Request(token_url, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    if "access_token" not in data:
        raise RuntimeError(f"获取文心 access_token 失败：{data}")
    return data["access_token"]


# ------------------------- 主调用函数 -------------------------
def get_llm_feedback(essay: str, config: ApiConfig = None, issues: str = "") -> str:
    """
    调用大模型 API，返回对作文的深度点评（字符串）。
    - 若 config 为 None 或 enabled=False 或无 api_key，则返回模拟点评。
    - issues：本地已检出的问题摘要（作为附加上下文，提升点评针对性）。
    - 成功返回模型点评；网络/鉴权出错时在末尾附上模拟点评作为兜底。
    """
    if not essay or not essay.strip():
        return "⚠️ 请先输入作文内容。"

    if config is None:
        from api_config import load_config
        config = load_config()

    # 未启用 / 无 Key → 走本地模拟，不发起网络请求
    if not config.enabled or not config.api_key.strip():
        return _mock_feedback(essay)

    prompts = _get_prompts()
    gen_params = prompts.generation_params(model=config.model)
    system, user = _build_prompt(essay, issues)
    timeout = int(config.timeout)

    try:
        if config.provider == "wenxin":
            # 文心一言：access_token 鉴权
            token = _get_wenxin_access_token(config.api_key, config.api_url, timeout)
            url = f"{config.api_url}?access_token={token}"
            payload = {
                "messages": [
                    {"role": "user", "content": system + "\n\n" + user},
                ],
                "model": config.model,
                "temperature": gen_params.get("temperature", 0.7),
            }
            headers = {"Content-Type": "application/json"}
            resp = _post_json(url, payload, headers, timeout)
            # 文心响应格式略有不同
            result = resp.get("result") or _extract_content(resp)
            return _format_feedback(result)

        else:
            # OpenAI 兼容格式（openai / deepseek / qwen / custom）
            payload = {
                "model": config.model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "temperature": gen_params.get("temperature", 0.7),
                "max_tokens": gen_params.get("max_tokens", 1500),
            }
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {config.api_key}",
            }
            resp = _post_json(config.api_url, payload, headers, timeout)
            return _format_feedback(_extract_content(resp))

    except urllib.error.HTTPError as e:
        # 解析接口返回的错误体（如 401 鉴权失败、429 限流等）
        try:
            err_body = json.loads(e.read().decode("utf-8"))
            err_msg = err_body.get("error", {}).get("message") or err_body
        except Exception:
            err_msg = str(e)
        return (
            f"⚠️ API 调用失败（HTTP {e.code}）：\n{err_msg}\n\n"
            "以下为本地模拟点评（仅供参考）：\n" + _mock_feedback(essay)
        )
    except Exception as e:
        return (
            f"⚠️ 调用大模型时出错：{e}\n\n"
            "以下为本地模拟点评（仅供参考）：\n" + _mock_feedback(essay)
        )


def _format_feedback(text: str) -> str:
    """统一包装模型返回的点评文本。"""
    return "🤖 大模型深度点评（由配置的接口生成）\n\n" + text.strip()


# ------------------------- 修改后范文（固定提示词） -------------------------
def generate_revised_essay(essay: str, config: ApiConfig = None) -> str:
    """
    调用大模型生成「修改后的范文」（固定提示词，需求核心）。
    - 使用 prompt_config 中的 rewrite_system / rewrite_user（用户可编辑）；
    - 这两段为"固定提示词"，保证 AI 点评后一定会输出润色后的完整范文；
    - 未启用 / 无 Key 时返回本地简单润色（兜底）。

    参数:
        essay:  原文
        config: ApiConfig；为 None 时自动加载

    返回:
        字符串：包含「修改说明」与「修改后的范文」两部分。
    """
    if not essay or not essay.strip():
        return "⚠️ 请先输入作文内容。"

    if config is None:
        config = load_config()

    prompts = _get_prompts()
    messages = prompts.build_rewrite_messages(essay)
    gen_params = prompts.generation_params(model=config.model)
    timeout = int(config.timeout)

    # 未启用 / 无 Key → 本地兜底，不发起网络请求
    if not config.enabled or not config.api_key.strip():
        return _format_revision(_local_rewrite(essay))

    try:
        if config.provider == "wenxin":
            token = _get_wenxin_access_token(config.api_key, config.api_url, timeout)
            url = f"{config.api_url}?access_token={token}"
            payload = {
                "messages": [{"role": "user",
                               "content": messages[0]["content"] + "\n\n" + messages[1]["content"]}],
                "model": config.model,
            }
            headers = {"Content-Type": "application/json"}
            resp = _post_json(url, payload, headers, timeout)
            result = resp.get("result") or _extract_content(resp)
            return _format_revision(result, gen_params.get("max_tokens"))

        else:
            payload = {
                "model": config.model,
                "messages": messages,
                "temperature": gen_params.get("temperature", 0.7),
                "max_tokens": gen_params.get("max_tokens", 1500),
            }
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {config.api_key}",
            }
            resp = _post_json(config.api_url, payload, headers, timeout)
            return _format_revision(_extract_content(resp), gen_params.get("max_tokens"))

    except urllib.error.HTTPError as e:
        try:
            err_body = json.loads(e.read().decode("utf-8"))
            err_msg = err_body.get("error", {}).get("message") or err_body
        except Exception:
            err_msg = str(e)
        return (
            f"⚠️ 生成范文失败（HTTP {e.code}）：{err_msg}\n\n"
            "以下为本地简单润色（仅供参考）：\n" + _format_revision(_local_rewrite(essay))
        )
    except Exception as e:
        return (
            f"⚠️ 生成范文时出错：{e}\n\n"
            "以下为本地简单润色（仅供参考）：\n" + _format_revision(_local_rewrite(essay))
        )


def _format_revision(text: str, max_tokens: int = None) -> str:
    """
    统一包装范文生成结果，并标注本次「实际生效的 max_tokens」。
    这样用户在界面上调成 6000，就能在结果里直接看到「max_tokens = 6000」，
    确认没有被截断、没有被 Spinbox 上限卡住。
    """
    cap_note = f"（本次 max_tokens = {int(max_tokens)})" if max_tokens else ""
    header = (
        "✍️ 修改后的范文（由配置的接口 + 固定提示词生成）\n"
        "（含【修改说明】与【修改后的范文】两部分）\n"
    )
    if cap_note:
        header += cap_note + "\n\n"
    else:
        header += "\n"
    return header + text.strip()


def _local_rewrite(essay: str) -> str:
    """无 API 时的本地兜底：仅做规则层面的简单改写说明。"""
    from grammar_checker import GrammarChecker
    checker = GrammarChecker()
    issues = checker.check(essay)
    lines = ["===== 修改说明 ====="]
    if issues:
        seen = set()
        for i in issues:
            key = i["message"]
            if key in seen:
                continue
            seen.add(key)
            lines.append(f"- 原文：{i['context']} → 建议：{i['suggestion']}")
    else:
        lines.append("- 未发现明显问题，表达基本正确。")
    lines.append("\n===== 修改后的范文 =====")
    lines.append("（未配置 API，暂无法生成 AI 润色范文；请到「⚙️ API 设置」启用大模型后重试。）")
    return "\n".join(lines)


# ------------------------- 连通性测试 -------------------------
def test_connection(config: ApiConfig) -> tuple:
    """
    用一条最小请求测试接口连通性（不点评完整作文，省 token）。
    返回 (是否成功: bool, 提示信息: str)。
    """
    if not config or not config.enabled:
        return False, "大模型点评未启用。"
    if not config.api_key.strip():
        return False, "未填写 API Key。"
    if not config.api_url.strip():
        return False, "未填写接口地址（API URL）。"

    # 构造一条极短的测试消息
    system = "你是英语教师。"
    user = "请只回复一个英文单词：ok"
    timeout = min(int(config.timeout), 15)  # 测试最多 15 秒

    try:
        if config.provider == "wenxin":
            token = _get_wenxin_access_token(config.api_key, config.api_url, timeout)
            url = f"{config.api_url}?access_token={token}"
            payload = {
                "messages": [{"role": "user", "content": user}],
                "model": config.model,
            }
            headers = {"Content-Type": "application/json"}
            resp = _post_json(url, payload, headers, timeout)
            if resp.get("result") or resp.get("choices"):
                return True, "连接成功 ✅ 接口可正常访问。"
            return False, f"接口返回异常：{resp}"

        else:
            payload = {
                "model": config.model,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                "max_tokens": 5,
            }
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {config.api_key}",
            }
            resp = _post_json(config.api_url, payload, headers, timeout)
            if resp.get("choices"):
                return True, "连接成功 ✅ 接口可正常访问。"
            return False, f"接口返回异常：{resp}"

    except urllib.error.HTTPError as e:
        try:
            err_body = json.loads(e.read().decode("utf-8"))
            err_msg = err_body.get("error", {}).get("message") or err_body
        except Exception:
            err_msg = str(e)
        return False, f"连接失败（HTTP {e.code}）：{err_msg}"
    except Exception as e:
        return False, f"连接失败：{e}"


# ------------------------- 本地模拟点评（兜底） -------------------------
def _mock_feedback(essay: str) -> str:
    """配置不完整或未启用时，基于简单规则生成模拟点评。"""
    feedback = []
    word_count = len(essay.split())

    feedback.append("📌 **整体评价**")
    if word_count < 80:
        feedback.append("- 文章篇幅偏短，建议扩展论点，增加论证细节。")
    elif word_count > 250:
        feedback.append("- 文章篇幅充实，注意避免冗余表达。")
    else:
        feedback.append("- 篇幅适中，结构较为完整。")

    feedback.append("\n📌 **优点**")
    feedback.append("- 观点表达清晰，能够围绕主题展开。")
    feedback.append("- 使用了一定的连接词，行文有一定连贯性。")

    feedback.append("\n📌 **改进建议**")
    feedback.append("- 部分句子存在语法瑕疵，建议注意主谓一致和时态统一。")
    feedback.append("- 可适当引入更高级的词汇和多样化句型（如从句、倒装）。")
    feedback.append("- 结论段可进一步升华，避免简单重复前文。")

    feedback.append("\n📌 **示例改写**")
    feedback.append("> 原文若使用 more better 等表达，可优化为 better / much better。")
    feedback.append("> 长句可拆分为短句，提升可读性。")

    return "\n".join(feedback)


# ------------------------- 获取模型列表 -------------------------
def fetch_models(base_url: str, api_key: str, timeout: int = 10) -> tuple:
    """
    自动获取接口地址下所有可用模型名称。
    利用 OpenAI 兼容的 GET /v1/models 端点。

    参数:
        base_url: 接口基地址，如 https://max.openai365.top/v1
                  也接受完整地址 https://xxx.com/v1/chat/completions（会自动裁剪）
        api_key:  API 密钥
        timeout:  请求超时（秒），默认 10 秒（仅获取列表，不宜过长）

    返回:
        (success: bool, models: list[str], error_msg: str)
        - 成功: (True, ["gpt-3.5-turbo", "gpt-4o", ...], "")
        - 失败: (False, [], "错误原因")

    说明:
        - 该函数可独立调用，不依赖 ApiConfig 对象，方便设置界面直接使用。
        - 若服务端未实现 /v1/models 端点，会返回 False，此时应降级为手动输入。
    """
    if not base_url or not base_url.strip():
        return False, [], "未填写接口地址（API URL）。"
    if not api_key or not api_key.strip():
        return False, [], "未填写 API Key。"

    # ---- 规范化 base_url：截取到 /v1 ----
    # 用户可能填：
    #   https://max.openai365.top/v1/chat/completions  → 裁剪为 .../v1
    #   https://max.openai365.top/v1                    → 保持不变
    #   https://max.openai365.top                       → 追加 /v1
    base = base_url.strip().rstrip("/")
    if "/chat/completions" in base:
        # 去掉 /chat/completions 后缀
        base = base.split("/chat/completions")[0].rstrip("/")
    if not base.endswith("/v1"):
        # 若末尾既不是 /v1 也不是 /v1/...，则追加 /v1
        if not base.endswith("/v1/models"):
            base = base + "/v1"

    models_url = base + "/models"

    try:
        req = urllib.request.Request(models_url)
        req.add_header("Authorization", f"Bearer {api_key}")
        req.add_header("Accept", "application/json")

        # 获取模型列表用较短超时（避免卡死）
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        # OpenAI 标准响应格式：{"object": "list", "data": [{"id": "...", ...}, ...]}
        if isinstance(data, dict) and "data" in data:
            models = []
            for item in data["data"]:
                mid = item.get("id") or item.get("name") or ""
                if mid:
                    models.append(mid)
            if models:
                # 按名称排序，方便用户查找
                models.sort()
                return True, models, ""
            return False, [], "接口返回的模型列表为空。"
        else:
            # 响应格式不符合预期
            return False, [], f"响应格式异常（非标准 /v1/models）：{json.dumps(data, ensure_ascii=False)[:200]}"

    except urllib.error.HTTPError as e:
        # 404 = 该端点不存在；其他 = 鉴权等错误
        try:
            err_body = json.loads(e.read().decode("utf-8"))
            err_msg = err_body.get("error", {}).get("message") or err_body
        except Exception:
            err_msg = str(e)
        if e.code == 404:
            return False, [], f"该接口不支持 /v1/models 自动获取（HTTP 404）。可手动输入模型名。"
        return False, [], f"HTTP {e.code}：{err_msg}"

    except urllib.error.URLError as e:
        return False, [], f"网络连接失败：{e.reason}（请检查地址是否正确、网络是否畅通）"

    except Exception as e:
        return False, [], f"获取失败：{type(e).__name__}：{e}"


# ------------------------- 自测入口 -------------------------
if __name__ == "__main__":
    # 直接运行本文件可做离线（模拟）测试，不发起网络请求
    sample = "Nowdays, with the development of society, students use alot of time on phone."
    print(get_llm_feedback(sample))  # 无 config，走模拟

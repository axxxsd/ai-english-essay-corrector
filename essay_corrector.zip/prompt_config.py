# -*- coding: utf-8 -*-
"""
prompt_config.py
模型提示词配置管理：让用户可以自行编辑「点评提示词」与「修改后范文提示词」。

设计思路：
1. 提示词与 API 配置（api_config.py）解耦——提示词是"怎么问"，接口是"问谁"，二者独立维护。
2. 内置一套【默认提示词】（DEFAULT_PROMPTS），含固定的"修改后范文"生成指令，保证 AI
   点评后一定会输出一篇润色后的范文（满足需求："新增固定提示词能让 AI 在点评后生成修改后的范文"）。
3. 用户可在界面上自由修改；修改后保存到本地 prompts.json，下次启动自动加载。
4. 若用户把提示词清空，调用时自动回退到默认提示词（永不失效）。
"""
import json
import os


# 默认提示词存放目录：与 api_config.py 共用 config/ 目录
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_DIR = os.path.join(BASE_DIR, "config")
DEFAULT_PROMPTS_PATH = os.path.join(CONFIG_DIR, "prompts.json")


# ============================================================
# 默认 / 固定提示词模板（内置，作为出厂设置与兜底）
# ============================================================
DEFAULT_PROMPTS = {
    # ---- 角色设定（两部分共用，单独抽出方便统一调整）----
    "role": (
        "你是一位资深的英语教师（English teacher & IELTS/TOEFL examiner），"
        "擅长英语写作批改、语法纠错与地道表达润色。"
    ),

    # ---- 点评提示词（system 部分）----
    # {role} 会被自动替换为上面的角色设定
    "feedback_system": (
        "{role}\n\n"
        "请按以下四个维度，对下面这篇英语作文进行专业、具体、可操作的点评，使用中文撰写：\n"
        "1. 【语法准确性】时态、主谓一致、冠词、拼写、句法错误；\n"
        "2. 【词汇丰富度】用词准确性、搭配、高级词汇与短语的使用；\n"
        "3. 【结构连贯性】段落结构、逻辑衔接、连接词运用；\n"
        "4. 【内容深度】论点展开、论证细节、立意与结论。\n\n"
        "在结尾请给出 1-2 句的【总体修改方向】。"
    ),

    # ---- 点评提示词（user 部分模板）----
    # {essay} = 原文，{issues} = 本地已检出的问题摘要（可选）
    "feedback_user": (
        "请点评以下英语作文：\n\n"
        "【作文原文】\n{essay}\n\n"
        "{issues}"
        "请按上述维度输出点评。"
    ),

    # ---- 修改后范文提示词（固定提示词，核心需求）----
    # 这部分为"固定提示词"：无论用户怎么改上面，都保证会要求模型输出润色后的范文。
    # {essay} = 原文
    "rewrite_system": (
        "{role}\n\n"
        "请基于下面的英语作文，完成两件事（严格按以下顺序、用分隔符区分）：\n\n"
        "第一步【修改说明】：用中文逐条列出你做的主要修改（语法纠错、词汇升级、句式优化、结构调整等），"
        "每条一行，格式为 \"- 原文：... → 改为：...\"。\n\n"
        "第二步【修改后的范文】：在修改说明之后，另起一段，以英文输出一篇润色后的完整范文。"
        "要求：\n"
        "- 保留原文的核心观点与立意，仅做语言层面的优化；\n"
        "- 修正所有语法、拼写、搭配错误；\n"
        "- 升级词汇与句型，提升表达地道性与多样性；\n"
        "- 保持段落结构清晰、逻辑连贯；\n"
        "- 字数与原文字数大致相当，不要大幅扩写或删减。\n\n"
        "【输出格式，请严格遵守】\n"
        "===== 修改说明 =====\n"
        "（此处写中文修改说明）\n\n"
        "===== 修改后的范文 =====\n"
        "（此处写英文润色后的完整范文）"
    ),

    "rewrite_user": (
        "请对以下英语作文进行修改，并按上述格式输出【修改说明】与【修改后的范文】：\n\n{essay}"
    ),

    # ---- 生成参数 ----
    # 注意：max_tokens 是「模型单次输出的最大 token 数」，不是总上限。
    # 生成「修改后范文」属于长文本输出，默认给 6000，避免被截断。
    # 若中转接口本身有更低上限，以接口为准（会返回 length 错误，届时可再调小）。
    "temperature": 0.7,
    "max_tokens": 6000,
}


class PromptConfig:
    """
    提示词配置对象。
    用户可在界面编辑 feedback_system / feedback_user / rewrite_system / rewrite_user，
    以及 temperature / max_tokens；role 为内部共用角色，一般无需修改。
    """
    def __init__(self, **kwargs):
        # 先用默认值打底，再用传入值覆盖 → 保证字段完整、向前兼容
        defaults = {k: v for k, v in DEFAULT_PROMPTS.items()}
        defaults.update({k: v for k, v in kwargs.items() if k in DEFAULT_PROMPTS})
        for k, v in defaults.items():
            setattr(self, k, v)

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in DEFAULT_PROMPTS}

    @classmethod
    def from_dict(cls, data: dict) -> "PromptConfig":
        # 忽略未知字段，保证向前兼容
        known = {k: v for k, v in data.items() if k in DEFAULT_PROMPTS}
        return cls(**known)

    # ---------------- 供调用层使用的渲染方法 ----------------
    def render_role(self) -> str:
        """返回填充好 role 的完整角色设定。"""
        return self.role

    def build_feedback_messages(self, essay: str, issues: str = "") -> list:
        """
        构造「点评」请求用的 messages（OpenAI 兼容格式）。
        issues：本地检出的问题摘要（可空）。
        """
        issues_block = issues.strip()
        user = self.feedback_user.format(
            essay=essay,
            issues=(issues_block + "\n\n") if issues_block else "",
        )
        return [
            {"role": "system", "content": self.feedback_system.format(role=self.role)},
            {"role": "user", "content": user},
        ]

    def build_rewrite_messages(self, essay: str) -> list:
        """
        构造「修改后范文」请求用的 messages（OpenAI 兼容格式）。
        这就是"固定提示词"生效的地方——无论界面怎么改，都强制要求输出范文。
        """
        user = self.rewrite_user.format(essay=essay)
        return [
            {"role": "system", "content": self.rewrite_system.format(role=self.role)},
            {"role": "user", "content": user},
        ]

    def generation_params(self, model: str = "") -> dict:
        """
        返回生成参数（temperature / max_tokens）。

        安全裁剪：多数 OpenAI 兼容模型对 max_tokens 有上限（常见 2048 / 4096，
        少数长文本模型可达 8192+）。若用户设的 max_tokens 超过模型上限，
        接口会返回 "max_tokens exceeds the model's maximum" 错误。
        这里按模型名做保守裁剪，避免盲目设 6000+ 触发接口报错。
        """
        requested = int(self.max_tokens)
        cap = _infer_max_tokens_cap(model or "") or 4096  # 未知模型保守按 4096
        safe_tokens = min(requested, cap)
        return {
            "temperature": float(self.temperature),
            "max_tokens": safe_tokens,
        }


def _infer_max_tokens_cap(model: str) -> int:
    """
    根据模型名推断其 max_tokens 输出上限（保守估计）。
    返回 0 表示无法识别（调用方按默认 4096 处理）。

    说明：这只是「避免报错」的兜底裁剪，不追求精确——
    精确值应以接口 /v1/models 返回的 model 字段为准。
    """
    m = (model or "").lower()
    if not m:
        return 0
    # 长文本 / 大模型系列：放宽为 8192
    if any(k in m for k in ("gpt-4", "gpt-4o", "deepseek", "qwen-max", "qwen-plus", "long")):
        return 8192
    # 16k / 32k / 128k 上下文模型：给足输出空间
    if "16k" in m or "32k" in m or "128k" in m or "turbo-16" in m:
        return 8192
    # 老款 / 小模型：2048
    if any(k in m for k in ("gpt-3.5-turbo-instruct", "curie", "babbage", "ada")):
        return 2048
    return 4096  # 默认保守值


# ============================================================
# 持久化：加载 / 保存
# ============================================================
def load_prompts(path: str = DEFAULT_PROMPTS_PATH) -> PromptConfig:
    """
    从 JSON 加载提示词配置；文件不存在或损坏时返回默认配置。
    保证：即使文件被清空/字段缺失，也用 DEFAULT_PROMPTS 兜底，永不失效。
    """
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return PromptConfig.from_dict(data)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return PromptConfig()


def save_prompts(prompts: PromptConfig, path: str = DEFAULT_PROMPTS_PATH) -> bool:
    """将提示词配置保存到 JSON。成功返回 True。"""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(prompts.to_dict(), f, ensure_ascii=False, indent=2)
        return True
    except OSError:
        return False


def reset_prompts() -> PromptConfig:
    """返回一套全新的默认提示词（用于界面上的"恢复默认"）。"""
    return PromptConfig()
